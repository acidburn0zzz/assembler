#ifndef CONDITIONS_H
#define CONDITIONS_H

extern const int NUM_COND;
extern const char *conditions[7];

#endif // CONDITION_H
